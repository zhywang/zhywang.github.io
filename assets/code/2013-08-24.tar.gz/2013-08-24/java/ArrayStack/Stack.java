public interface Stack<T> {
    boolean isEmpty();
    T pop();
    void push(T value);
}
